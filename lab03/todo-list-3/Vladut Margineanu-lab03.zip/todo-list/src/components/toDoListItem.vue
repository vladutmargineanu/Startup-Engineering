<template>
  <div class="to-do-list-item">
    <div v-if="editMode === true">
      <input type="text" v-model="inputText"/>
      <br/>
      <button @click="save" class="save">
        <svg version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 47 47" style="enable-background:new 0 0 47 47;" xml:space="preserve" width="20px" height="20px">
          <polygon style="fill:#424A60;" points="46.5,8 46.5,47 0.5,47 0.5,0 38.5,0 "/>
          <rect x="7.5" y="26" style="fill:#E7ECED;" width="31" height="21"/>
          <rect x="7.5" y="26" style="fill:#EBBA16;" width="31" height="12.037"/>
          <rect x="9.5" style="fill:#C7CAC7;" width="26" height="16"/>
          <g>
            <path style="fill:#FFFFFF;" d="M12.5,31h7c0.553,0,1-0.447,1-1s-0.447-1-1-1h-7c-0.553,0-1,0.447-1,1S11.947,31,12.5,31z"/>
            <path style="fill:#FFFFFF;" d="M22.5,33h-10c-0.553,0-1,0.447-1,1s0.447,1,1,1h10c0.553,0,1-0.447,1-1S23.053,33,22.5,33z"/>
            <path style="fill:#FFFFFF;" d="M26.21,33.29c-0.37-0.37-1.04-0.37-1.41,0c-0.19,0.189-0.3,0.439-0.3,0.71 c0,0.27,0.109,0.52,0.29,0.71C24.979,34.89,25.229,35,25.5,35c0.27,0,0.52-0.11,0.71-0.29c0.18-0.19,0.29-0.45,0.29-0.71 S26.39,33.479,26.21,33.29z"/>
          </g>
          <rect x="27.5" y="4" style="fill:none;stroke:#424A60;stroke-width:2;stroke-linecap:round;stroke-miterlimit:10;" width="4" height="8"/>
          <polygon style="fill:#E7ECED;" points="24.5,16 9.5,16 9.5,0 16.5,0 "/>
        </svg>
      </button>
    </div>
    <div v-else>
      <span>{{text}}</span>
      <br/>
      <button @click="edit" class="edit">
        <svg height="20px" viewBox="0 -1 401.5411 401" width="20px" xmlns="http://www.w3.org/2000/svg">
          <path d="m381.289062 32.242188c13.671876 13.664062 13.671876 35.824218 0 49.488281l-17.679687 17.679687-61.230469-61.230468 17.679688-17.679688c13.671875-13.667969 35.832031-13.667969 49.5 0zm0 0" fill="#00acea"/>
          <path d="m363.609375 99.410156-160.148437 160.160156h-.011719l-61.230469-61.230468 160.160156-160.160156zm0 0" fill="#00efd1"/>
          <path d="m142.21875 198.339844 61.230469 61.230468-.570313.570313-84.6875 23.460937 23.457032-84.691406zm0 0" fill="#fedb41"/>
          <g fill="#083863">
            <path d="m370.589844 250.960938c-5.523438 0-10 4.476562-10 10v88.789062c-.019532 16.5625-13.4375 29.980469-30 30h-280.589844c-16.5625-.019531-29.980469-13.4375-30-30v-260.589844c.019531-16.558594 13.4375-29.980468 30-30h88.789062c5.523438 0 10-4.476562 10-10 0-5.523437-4.476562-10-10-10h-88.789062c-27.601562.03125-49.96875 22.398438-50 50v260.589844c.03125 27.601562 22.398438 49.96875 50 50h280.589844c27.601562-.03125 49.96875-22.398438 50-50v-88.789062c0-5.523438-4.476563-10-10-10zm0 0"/>
            <path d="m376.632812 13.429688c-17.589843-17.546876-46.058593-17.546876-63.644531 0l-178.410156 178.410156c-1.21875 1.222656-2.105469 2.738281-2.566406 4.398437l-23.457031 84.691407c-.964844 3.472656.015624 7.191406 2.5625 9.742187 2.550781 2.546875 6.269531 3.527344 9.742187 2.566406l84.691406-23.460937c1.664063-.460938 3.183594-1.347656 4.40625-2.570313l.566407-.570312 177.835937-177.835938c17.574219-17.570312 17.574219-46.058593 0-63.628906zm-229.675781 203.789062 37.613281 37.617188-52.03125 14.414062zm56.5 42.355469v-.007813l6.519531 6.519532zm0-14.140625-47.09375-47.09375 146.015625-146.015625 47.089844 47.085937zm170.761719-170.773438-10.609375 10.609375-47.085937-47.089843 10.609374-10.609376c9.765626-9.746093 25.582032-9.746093 35.351563 0l11.734375 11.746094c9.765625 9.757813 9.765625 25.585938 0 35.34375zm0 0"/>
          </g>
        </svg>
      </button>
    </div>
    <button @click="remove" class="remove">
      <svg height="20px" viewBox="-31 0 512 512" width="20px" xmlns="http://www.w3.org/2000/svg">
        <path d="m300 45v30c0 8.402344-6.597656 15-15 15s-15-6.597656-15-15v-30c0-8.402344-6.597656-15-15-15h-60c-8.402344 0-15 6.597656-15 15v30c0 8.402344-6.597656 15-15 15s-15-6.597656-15-15v-30c0-24.902344 20.097656-45 45-45h60c24.902344 0 45 20.097656 45 45zm0 0" fill="#68544f"/><path d="m255 30h-30v-30h30c24.902344 0 45 20.097656 45 45v30c0 8.402344-6.597656 15-15 15s-15-6.597656-15-15v-30c0-8.402344-6.597656-15-15-15zm0 0" fill="#3e322e"/>
        <path d="m420 166h-390c0-57.898438 47.101562-106 105-106h180c57.898438 0 105 48.101562 105 106zm0 0" fill="#a8ebfa"/>
        <path d="m420 166h-195v-106h90c57.898438 0 105 48.101562 105 106zm0 0" fill="#25d9f8"/>
        <path d="m390 166v301c0 24.898438-20.097656 45-45 45h-240c-24.902344 0-45-20.101562-45-45v-301c0-8.402344 6.597656-15 15-15h300c8.402344 0 15 6.597656 15 15zm0 0" fill="#a8ebfa"/>
        <path d="m390 166v301c0 24.898438-20.097656 45-45 45h-120v-361h150c8.402344 0 15 6.597656 15 15zm0 0" fill="#25d9f8"/>
        <path d="m150 422c-8.289062 0-15-6.710938-15-15v-151c0-8.289062 6.710938-15 15-15s15 6.710938 15 15v151c0 8.289062-6.710938 15-15 15zm0 0" fill="#73bcff"/>
        <path d="m240 256v151c0 8.398438-6.597656 15-15 15s-15-6.601562-15-15v-151c0-8.402344 6.597656-15 15-15s15 6.597656 15 15zm0 0" fill="#73bcff"/>
        <path d="m300 422c-8.289062 0-15-6.710938-15-15v-151c0-8.289062 6.710938-15 15-15s15 6.710938 15 15v151c0 8.289062-6.710938 15-15 15zm0 0" fill="#0095ff"/>
        <path d="m240 256v151c0 8.398438-6.597656 15-15 15v-181c8.402344 0 15 6.597656 15 15zm0 0" fill="#0095ff"/>
        <path d="m450 166c0 8.398438-6.597656 15-15 15h-420c-8.402344 0-15-6.601562-15-15 0-8.402344 6.597656-15 15-15h420c8.402344 0 15 6.597656 15 15zm0 0" fill="#68544f"/>
        <path d="m450 166c0 8.398438-6.597656 15-15 15h-210v-30h210c8.402344 0 15 6.597656 15 15zm0 0" fill="#3e322e"/>
      </svg>
    </button>
  </div>
</template>

<script>
export default {
  name: 'toDoListItem',
  props: {
    id: {
      type: Number,
      rquired: true
    },
    text: {
      type: String,
      rquired: true
    }
  },
  data () {
    return {
      editMode: false,
      inputText: ''
    }
  },
  methods: {
    edit () {
      this.inputText = this.text
      this.editMode = true
    },
    save () {
      this.$emit('edit', this.id, this.inputText)
      this.editMode = false
    },
    remove () {
      this.$emit('remove', this.id)
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="scss">
.to-do-list-item {
  position: relative;
  border: 1px solid #cecece;
  border-radius: 10px;
  width: 300px;
  height: 50px;
  margin: 10px auto;
  padding:10px;
  box-sizing: border-box;
  input[type=text] {
    width: 80%;
    border:none;
    text-align: center;
    border-bottom:1px solid black;
    font-weight: bold;
  }
  span {
    width: 80%;
    overflow: hidden;
    display:inline-block;
    cursor: default;
    font-weight: bold;
  }
  button {
    position: absolute;
    margin: 5px;
    bottom: 0;
    cursor: pointer;
    background: transparent;
    border: none;
    &.edit, &.save {
      left: 0;
    }
    &.remove {
      right: 0;
    }
  }
}


</style>
