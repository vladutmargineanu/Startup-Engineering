<template>
  <div class="home">
    <img alt="Vue logo" src="../assets/logo.png">
    <toDoListItem
      v-for="item in listItems"
      :key="item.id"
      :id="item.id"
      :text="item.text"
      @edit="edit"
      @remove="remove"
    />
    <div class="new-item">
      <input v-model="inputText" type="text"/>
      <button @click="create">Crate</button>
    </div>
  </div>
</template>

<script>
// @ is an alias to /src
import toDoListItem from '@/components/toDoListItem.vue'

export default {
  name: 'home',
  components: {
    toDoListItem
  },
  data () {
    return {
      listItems: [
        {
          id: 0,
          text: 'task 1'
        },
        {
          id: 1,
          text: 'task 2'
        },
        {
          id: 32,
          text: 'task 3'
        }
      ],
      inputText: ''
    }
  },
  mounted () {
    if (localStorage.getItem('myToDoListItems') !== null) {
      this.listItems = JSON.parse(localStorage.getItem('myToDoListItems'))
    }
  },
  methods: {
    edit (id, newText) {
      let item = this.listItems.find(item => item.id === id)
      if (item) {
        item.text = newText
      }
      localStorage.setItem('myToDoListItems', JSON.stringify(this.listItems))
    },
    remove (id) {
      this.listItems = this.listItems.filter(item => item.id !== id)
      localStorage.setItem('myToDoListItems', JSON.stringify(this.listItems))
    },
    create () {
      if (this.inputText.trim() !== '') {
        this.listItems.push({
          id: Math.max(...this.listItems.map(item => item.id)) + 1,
          text: this.inputText.trim()
        })
        this.inputText = ''
        localStorage.setItem('myToDoListItems', JSON.stringify(this.listItems))
      }
    }
  }
}
</script>
